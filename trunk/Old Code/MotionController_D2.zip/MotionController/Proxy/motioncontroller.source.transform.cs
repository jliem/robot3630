﻿using System;
using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.Core.Transforms;

#if NET_CF20
[assembly: ServiceDeclaration(DssServiceDeclaration.Transform, SourceAssemblyKey = @"cf.motioncontroller.y2008.m02, version=0.0.0.0, culture=neutral, publickeytoken=d185a51f257aaa63")]
#else
[assembly: ServiceDeclaration(DssServiceDeclaration.Transform, SourceAssemblyKey = @"motioncontroller.y2008.m02, version=0.0.0.0, culture=neutral, publickeytoken=d185a51f257aaa63")]
#endif
#if !URT_MINCLR
[assembly: System.Security.SecurityTransparent]
[assembly: System.Security.AllowPartiallyTrustedCallers]
#endif

namespace Dss.Transforms.TransformMotionController
{

    public class Transforms: TransformBase
    {

        public static object Transform_Robotics_CoroBot_MotionController_Proxy_MotionControllerState_TO_Robotics_CoroBot_MotionController_MotionControllerState(object transformFrom)
        {
            Robotics.CoroBot.MotionController.MotionControllerState target = new Robotics.CoroBot.MotionController.MotionControllerState();
            Robotics.CoroBot.MotionController.Proxy.MotionControllerState from = transformFrom as Robotics.CoroBot.MotionController.Proxy.MotionControllerState;
            target.DistanceCalibration = from.DistanceCalibration;
            target.TurningCalibration = from.TurningCalibration;
            target.DrivingState = (Robotics.CoroBot.MotionController.DrivingStates)((System.Int32)from.DrivingState);
            target.EncoderCountdown = from.EncoderCountdown;
            target.EncoderCalibration = from.EncoderCalibration;
            target.Power = from.Power;
            return target;
        }


        public static object Transform_Robotics_CoroBot_MotionController_MotionControllerState_TO_Robotics_CoroBot_MotionController_Proxy_MotionControllerState(object transformFrom)
        {
            Robotics.CoroBot.MotionController.Proxy.MotionControllerState target = new Robotics.CoroBot.MotionController.Proxy.MotionControllerState();
            Robotics.CoroBot.MotionController.MotionControllerState from = transformFrom as Robotics.CoroBot.MotionController.MotionControllerState;
            target.DistanceCalibration = from.DistanceCalibration;
            target.TurningCalibration = from.TurningCalibration;
            target.DrivingState = (Robotics.CoroBot.MotionController.Proxy.DrivingStates)((System.Int32)from.DrivingState);
            target.EncoderCountdown = from.EncoderCountdown;
            target.EncoderCalibration = from.EncoderCalibration;
            target.Power = from.Power;
            return target;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_DriveRequest_TO_Robotics_CoroBot_MotionController_DriveRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.DriveRequest target = new Robotics.CoroBot.MotionController.DriveRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.DriveRequest _instance_Robotics_CoroBot_MotionController_Proxy_DriveRequest = new Robotics.CoroBot.MotionController.Proxy.DriveRequest();
        public static object Transform_Robotics_CoroBot_MotionController_DriveRequest_TO_Robotics_CoroBot_MotionController_Proxy_DriveRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_DriveRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_TurnRequest_TO_Robotics_CoroBot_MotionController_TurnRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.TurnRequest target = new Robotics.CoroBot.MotionController.TurnRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.TurnRequest _instance_Robotics_CoroBot_MotionController_Proxy_TurnRequest = new Robotics.CoroBot.MotionController.Proxy.TurnRequest();
        public static object Transform_Robotics_CoroBot_MotionController_TurnRequest_TO_Robotics_CoroBot_MotionController_Proxy_TurnRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_TurnRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest_TO_Robotics_CoroBot_MotionController_BeginCalibrateDriveRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.BeginCalibrateDriveRequest target = new Robotics.CoroBot.MotionController.BeginCalibrateDriveRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.BeginCalibrateDriveRequest _instance_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest = new Robotics.CoroBot.MotionController.Proxy.BeginCalibrateDriveRequest();
        public static object Transform_Robotics_CoroBot_MotionController_BeginCalibrateDriveRequest_TO_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest_TO_Robotics_CoroBot_MotionController_BeginCalibrateTurnRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.BeginCalibrateTurnRequest target = new Robotics.CoroBot.MotionController.BeginCalibrateTurnRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.BeginCalibrateTurnRequest _instance_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest = new Robotics.CoroBot.MotionController.Proxy.BeginCalibrateTurnRequest();
        public static object Transform_Robotics_CoroBot_MotionController_BeginCalibrateTurnRequest_TO_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest_TO_Robotics_CoroBot_MotionController_SetDriveCalibrationRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.SetDriveCalibrationRequest target = new Robotics.CoroBot.MotionController.SetDriveCalibrationRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.SetDriveCalibrationRequest _instance_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest = new Robotics.CoroBot.MotionController.Proxy.SetDriveCalibrationRequest();
        public static object Transform_Robotics_CoroBot_MotionController_SetDriveCalibrationRequest_TO_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest_TO_Robotics_CoroBot_MotionController_SetTurnCalibrationRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.SetTurnCalibrationRequest target = new Robotics.CoroBot.MotionController.SetTurnCalibrationRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.SetTurnCalibrationRequest _instance_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest = new Robotics.CoroBot.MotionController.Proxy.SetTurnCalibrationRequest();
        public static object Transform_Robotics_CoroBot_MotionController_SetTurnCalibrationRequest_TO_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_StopRequest_TO_Robotics_CoroBot_MotionController_StopRequest(object transformFrom)
        {
            Robotics.CoroBot.MotionController.StopRequest target = new Robotics.CoroBot.MotionController.StopRequest();
            return target;
        }


        private static Robotics.CoroBot.MotionController.Proxy.StopRequest _instance_Robotics_CoroBot_MotionController_Proxy_StopRequest = new Robotics.CoroBot.MotionController.Proxy.StopRequest();
        public static object Transform_Robotics_CoroBot_MotionController_StopRequest_TO_Robotics_CoroBot_MotionController_Proxy_StopRequest(object ignore)
        {
            return _instance_Robotics_CoroBot_MotionController_Proxy_StopRequest;
        }


        public static object Transform_Robotics_CoroBot_MotionController_Proxy_DrivingStates_TO_Robotics_CoroBot_MotionController_DrivingStates(object transformFrom)
        {
            Robotics.CoroBot.MotionController.DrivingStates target = new Robotics.CoroBot.MotionController.DrivingStates();
            return target;
        }


        public static object Transform_Robotics_CoroBot_MotionController_DrivingStates_TO_Robotics_CoroBot_MotionController_Proxy_DrivingStates(object transformFrom)
        {
            Robotics.CoroBot.MotionController.Proxy.DrivingStates target = new Robotics.CoroBot.MotionController.Proxy.DrivingStates();
            return target;
        }

        static Transforms()
        {
            Register();
        }
        public static void Register()
        {
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.MotionControllerState), Transform_Robotics_CoroBot_MotionController_Proxy_MotionControllerState_TO_Robotics_CoroBot_MotionController_MotionControllerState);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.MotionControllerState), Transform_Robotics_CoroBot_MotionController_MotionControllerState_TO_Robotics_CoroBot_MotionController_Proxy_MotionControllerState);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.DriveRequest), Transform_Robotics_CoroBot_MotionController_Proxy_DriveRequest_TO_Robotics_CoroBot_MotionController_DriveRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.DriveRequest), Transform_Robotics_CoroBot_MotionController_DriveRequest_TO_Robotics_CoroBot_MotionController_Proxy_DriveRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.TurnRequest), Transform_Robotics_CoroBot_MotionController_Proxy_TurnRequest_TO_Robotics_CoroBot_MotionController_TurnRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.TurnRequest), Transform_Robotics_CoroBot_MotionController_TurnRequest_TO_Robotics_CoroBot_MotionController_Proxy_TurnRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.BeginCalibrateDriveRequest), Transform_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest_TO_Robotics_CoroBot_MotionController_BeginCalibrateDriveRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.BeginCalibrateDriveRequest), Transform_Robotics_CoroBot_MotionController_BeginCalibrateDriveRequest_TO_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateDriveRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.BeginCalibrateTurnRequest), Transform_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest_TO_Robotics_CoroBot_MotionController_BeginCalibrateTurnRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.BeginCalibrateTurnRequest), Transform_Robotics_CoroBot_MotionController_BeginCalibrateTurnRequest_TO_Robotics_CoroBot_MotionController_Proxy_BeginCalibrateTurnRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.SetDriveCalibrationRequest), Transform_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest_TO_Robotics_CoroBot_MotionController_SetDriveCalibrationRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.SetDriveCalibrationRequest), Transform_Robotics_CoroBot_MotionController_SetDriveCalibrationRequest_TO_Robotics_CoroBot_MotionController_Proxy_SetDriveCalibrationRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.SetTurnCalibrationRequest), Transform_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest_TO_Robotics_CoroBot_MotionController_SetTurnCalibrationRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.SetTurnCalibrationRequest), Transform_Robotics_CoroBot_MotionController_SetTurnCalibrationRequest_TO_Robotics_CoroBot_MotionController_Proxy_SetTurnCalibrationRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.StopRequest), Transform_Robotics_CoroBot_MotionController_Proxy_StopRequest_TO_Robotics_CoroBot_MotionController_StopRequest);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.StopRequest), Transform_Robotics_CoroBot_MotionController_StopRequest_TO_Robotics_CoroBot_MotionController_Proxy_StopRequest);
            AddProxyTransform(typeof(Robotics.CoroBot.MotionController.Proxy.DrivingStates), Transform_Robotics_CoroBot_MotionController_Proxy_DrivingStates_TO_Robotics_CoroBot_MotionController_DrivingStates);
            AddSourceTransform(typeof(Robotics.CoroBot.MotionController.DrivingStates), Transform_Robotics_CoroBot_MotionController_DrivingStates_TO_Robotics_CoroBot_MotionController_Proxy_DrivingStates);
        }
    }
}

